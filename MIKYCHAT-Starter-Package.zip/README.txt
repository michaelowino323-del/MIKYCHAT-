MIKYCHAT STARTER PACKAGE

Files:
- index.html: Supabase email/password auth and creator application form.
- MIKYCHAT-Supabase-Setup.sql: creator application table with Row Level Security.

Publish:
1. Upload this package's index.html to https://github.com/michaelowino323-del/MIKYCHAT- and replace the old index.html.
2. In Supabase Dashboard > SQL Editor, run the entire SQL file.
3. In Supabase Dashboard > Authentication > URL Configuration, set Site URL and allowed redirect URL to:
   https://michaelowino323-del.github.io/MIKYCHAT-/
4. Enable email sign-ups and configure email confirmation.
5. Test account creation and login.

Limitations:
- Never place a Supabase secret/service-role key in public HTML.
- Creator applications are pending only. The adult checkbox is not real age or identity verification. A specialist verification provider and secure server-side status handling must be configured before approval. Do not collect ID document images in this basic form.
- Payments are NOT active; this page will not charge money. To add real tips/subscriptions/payouts, select a payment provider that explicitly allows the intended business and content category, create a merchant account, and implement server-side checkout plus verified webhooks. Store secret keys in Supabase Edge Function secrets, never in HTML.
- Live video, moderation/admin dashboard, and creator payouts are not implemented in this starter.
