-- MIKYCHAT starter database setup
-- Run in Supabase Dashboard > SQL Editor > New query > Run.
-- This stores applications only; it does not verify age/identity or process payments.
create table if not exists public.creator_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 50),
  country text not null check (char_length(country) between 1 and 80),
  bio text not null default '' check (char_length(bio) <= 300),
  contact_email text not null,
  status text not null default 'pending' check (status in ('pending','in_review','approved','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.creator_applications enable row level security;
drop policy if exists "Users can submit their own creator application" on public.creator_applications;
create policy "Users can submit their own creator application"
on public.creator_applications for insert to authenticated
with check (auth.uid() = user_id and status = 'pending');
drop policy if exists "Users can view their own creator applications" on public.creator_applications;
create policy "Users can view their own creator applications"
on public.creator_applications for select to authenticated
using (auth.uid() = user_id);
-- No client update/delete policy: users must not be able to approve themselves.
